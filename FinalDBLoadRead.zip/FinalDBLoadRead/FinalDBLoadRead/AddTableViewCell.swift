//
//  AddTableViewCell.swift
//  FinalDBLoadRead
//
//  Created by karan Mishra on 10/11/16.
//  Copyright © 2016 Tagit. All rights reserved.
//

import UIKit

class AddTableViewCell: UITableViewCell {

    @IBOutlet var addpopulationTxt: UITextField!
    @IBOutlet var addcountryTxt: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
