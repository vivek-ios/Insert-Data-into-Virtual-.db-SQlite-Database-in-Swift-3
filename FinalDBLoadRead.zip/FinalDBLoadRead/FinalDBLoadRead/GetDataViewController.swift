//
//  GetDataViewController.swift
//  FinalDBLoadRead
//
//  Created by karan Mishra on 10/11/16.
//  Copyright © 2016 Tagit. All rights reserved.
//

import UIKit

class GetDataViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate {

    @IBOutlet var DbTableview: UITableView!
    
    var DbDataArray = NSMutableArray()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
self.GetData()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func GetData() {
        
        DbDataArray = GetDataFromDB()
        
        DbTableview.reloadData()

    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
    return 1
        
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
        return DbDataArray.count
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell:GetTableViewCell = tableView.dequeueReusableCellWithIdentifier("GetTableViewCell") as! GetTableViewCell
        let repo:ModelData = DbDataArray.objectAtIndex(indexPath.row) as! ModelData
        cell.countryTxt.text = repo.Country
        cell.populationTxt.text = repo.Population
        
        return cell

        
    }
    func GetDataFromDB()  -> NSMutableArray{
        
        let marrEmergencyContactsInfo : NSMutableArray = NSMutableArray()
        if let medDB: FMDatabase = ViewController().MedDocketDB {
            if medDB.open() {
                let resultSet: FMResultSet! = medDB.executeQuery("SELECT country, population FROM jaffadata", withArgumentsInArray: nil)
                if (resultSet != nil) {
                    while resultSet.next() {
                        let Repo : ModelData = ModelData()
                        let Country = resultSet.stringForColumn("country")
                        let Population: String = resultSet.stringForColumn("population")
                        
                        Repo.Country = Country != "" ? Country : ""
                        Repo.Population = Population != "" ? Population : ""
                        
                        marrEmergencyContactsInfo.addObject(Repo)
                    }
                }
            }
        }
        return marrEmergencyContactsInfo
    }

        
/*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
class ModelData: NSObject
{
    var Country: String = String()
    var Population: String = String()
}
