//
//  ViewController.swift
//  FinalDBLoadRead
//
//  Created by karan Mishra on 10/11/16.
//  Copyright © 2016 Tagit. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    let preferences = NSUserDefaults()
    
    var MedDocketDB: FMDatabase {
        get {
            var DB = FMDatabase()
            let databasePath:String = preferences.stringForKey("databasePath")!
            let filemgr = NSFileManager.defaultManager()
            if filemgr.fileExistsAtPath(databasePath) {
                DB = FMDatabase(path: databasePath as String)
            }
            return DB
        }
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

